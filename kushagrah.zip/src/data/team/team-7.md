---
#preview details
image: /images/gems/Premiere Pro.png
name: Adobe Premiere Pro
role: Art Director
first_letter: P
social:
  - link: https://facebook.com/
    icon: fab fa-facebook-f
    title: Facebook

  - link: https://linkedin.com/
    icon: fab fa-linkedin-in
    title: Linkedin

#full details
info:
  - label: Age
    value: 25 Years
  
  - label: Location
    value: Baird House, 15-17 St Cross St London EC1N 8UW
  
  - label: Email
    value: lina.watson@domain.com

  - label: Phone No
    value: +44 (0) 20 7430 2973

services: 
  - service-1
  - service-2
  - service-3
  - service-4
  - service-5

awards:
  - label: 7 SOTD <br> 17 HONORABLE MENTION <br> 3 MOBILE EXCELLENCE
    value: 31
    image: /images/award1.png

  - label: 11 SOTD <br> 5 SPECIAL KUDOS
    value: 16
    image: /images/award2.png

  - label: AWARD 2019 <br> 1 GLOBAL COMPETITION
    value: 20
    image: /images/award3.png

projects: 
  - project-04
  - project-05
  - project-06
  - project-07
---

### What is your professional passion?

- Far curiosity incommode now led smallness allowance.
- Favour bed assure son things yet.
- She consisted consulted elsewhere happiness.
- Widow downs you new shade drift hopes small.
- Interested discretion estimating on stimulated.

The most exciting would be that no day is ever the same and each day brings new challenges. My professional passion would be team morale and relationship building. I think the true measure of success in an organization is to gage employee satisfaction, engagement nd the relationships that they build. I truly never envisioned that Construction would have been the organization that empowers. The most exciting would be that no day is ever the same and each day brings new challenges. My professional passion would be team morale and relationship building.

Moorings Park Grande Lake. It’s my favorite because of the vast layers of the project from building structure to the customization in the building. (Only one I’ve been on so far but LOVE it)
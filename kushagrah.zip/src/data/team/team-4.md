---
#preview details
image: /images/gems/InDesign.png
name: Adobe Indesign
role: Seo & Copywriter
first_letter: I
social:
  - link: https://facebook.com/
    icon: fab fa-facebook-f
    title: Facebook

  - link: https://linkedin.com/
    icon: fab fa-linkedin-in
    title: Linkedin

#full details
info:
  - label: Age
    value: 35 Years
  
  - label: Location
    value: Baird House, 15-17 St Cross St London EC1N 8UW
  
  - label: Email
    value: charlotte.johnson@domain.com

  - label: Phone No
    value: +44 (0) 20 7430 2973

services: 
  - service-1
  - service-2
  - service-3
  - service-4
  - service-5

awards:
  - label: 7 SOTD <br> 17 HONORABLE MENTION <br> 3 MOBILE EXCELLENCE
    value: 21
    image: /images/award1.png

  - label: 11 SOTD <br> 5 SPECIAL KUDOS
    value: 15
    image: /images/award2.png

  - label: AWARD 2019 <br> 1 GLOBAL COMPETITION
    value: 19
    image: /images/award3.png

projects: 
  - project-05
  - project-06
  - project-07
  - project-08
---

### What is your professional passion?

The most exciting would be that no day is ever the same and each day brings new challenges. My professional passion would be team morale and relationship building. I think the true measure of success in an organization is to gage employee satisfaction, engagement nd the relationships that they build. I truly never envisioned that Construction would have been the organization that empowers. The most exciting would be that no day is ever the same and each day brings new challenges. My professional passion would be team morale and relationship building.

In addition to construction consultancy services **Bureau Veritas is a global leader in testing**, inspection and certification (TIC) and we have more than 190+ years of experience meaning that we also can assist you in other areas of your business if needed.